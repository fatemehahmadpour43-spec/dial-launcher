package com.dial.launcher

import android.content.Intent
import android.graphics.Color as AColor
import android.os.Bundle
import android.provider.AlarmClock
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.launch
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

class MainActivity : ComponentActivity() {
    private val homePressed = MutableSharedFlow<Unit>(extraBufferCapacity = 1)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT),
        )
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFFF5C518))) { Root(homePressed) } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        homePressed.tryEmit(Unit)
    }
}

/* ---------------- رنگ‌ها ---------------- */

val Accents = listOf(Color(0xFFF5C518), Color(0xFFC6F432), Color(0xFFFF7EB6), Color(0xFF5CE1E6))
private val Panel = Color(0xFF141414)
private val Card = Color(0xFFD9D9D9)
private val Ink = Color(0xFF1B1B1B)
private val Dim = Color(0xFF8A8A8A)

class Ui(val prefs: Prefs) {
    val accent get() = Accents.getOrElse(prefs.get("accent", "0")!!.toInt()) { Accents[0] }
    val fa get() = prefs.flag("persian", false)
}

private val LocalUi = staticCompositionLocalOf<Ui> { error("ui") }

private fun fmt(now: Long, pattern: String, fa: Boolean): String =
    if (fa) android.icu.text.SimpleDateFormat(pattern, android.icu.util.ULocale("fa_IR@calendar=persian")).format(Date(now))
    else java.text.SimpleDateFormat(pattern, Locale.ENGLISH).format(Date(now))

@OptIn(ExperimentalFoundationApi::class)
private fun Modifier.tap(onLong: (() -> Unit)? = null, onClick: () -> Unit) =
    combinedClickable(onClick = onClick, onLongClick = onLong)

/* ---------------- ریشه ---------------- */

@Composable
fun Root(homePressed: SharedFlow<Unit>) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { Prefs(ctx) }
    val ui = remember { Ui(prefs) }
    var apps by remember { mutableStateOf<List<AppInfo>>(emptyList()) }
    var settings by remember { mutableStateOf(false) }
    var editQuote by remember { mutableStateOf(false) }
    val pager = rememberPagerState(initialPage = 1) { 2 }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { scope.launch { apps = loadApps(ctx) } }
    LaunchedEffect(Unit) {
        homePressed.collect { settings = false; editQuote = false; pager.animateScrollToPage(1) }
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            prefs.set("wallpaper", uri.toString())
        }
    }
    BackHandler { scope.launch { pager.animateScrollToPage(1) } }

    CompositionLocalProvider(LocalUi provides ui) {
        Box(Modifier.fillMaxSize().background(Panel)) {
            HorizontalPager(pager, Modifier.fillMaxSize()) { page ->
                if (page == 0) DialPage(onLong = { settings = true })
                else HomePage(apps, onSettings = { settings = true }, onEditQuote = { editQuote = true })
            }
            if (settings) SettingsDialog(prefs, onWallpaper = { picker.launch(arrayOf("image/*")) }) { settings = false }
            if (editQuote) QuoteDialog(prefs) { editQuote = false }
        }
    }
}

/* ---------------- صفحهٔ ساعت چرخان ---------------- */

@Composable
private fun DialPage(onLong: () -> Unit) {
    val ui = LocalUi.current
    val ctx = LocalContext.current
    val now = rememberNow()
    val battery = rememberBattery()
    val cal = Calendar.getInstance().apply { timeInMillis = now }
    val minute = cal.get(Calendar.MINUTE)
    val target = cal.get(Calendar.HOUR_OF_DAY) * 60 + minute + cal.get(Calendar.SECOND) / 60f
    // چرخ آرام می‌چرخد؛ وقتی از ۵۹ به ۰ می‌رسد بدون پرش برمی‌گردد
    val rot by animateFloatAsState(target, tween(900), label = "dial")
    val tm = rememberTextMeasurer()
    val accent = ui.accent

    Box(
        Modifier.fillMaxSize().background(Color(0xFF101010))
            .pointerInput(Unit) { detectTapGestures(onLongPress = { onLong() }) }
            .statusBarsPadding().navigationBarsPadding(),
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val c = Offset(size.width * 0.34f, size.height * 0.46f)
            val r = size.width * 0.30f
            for (k in 0 until 60) {
                val a = Math.toRadians(((k - rot) * 6.0))
                val p = Offset(c.x + (r * cos(a)).toFloat(), c.y + (r * sin(a)).toFloat())
                val x = ((k - rot) % 60 + 60) % 60
                val fade = 1f - 0.75f * minOf(x, 60 - x) / 30f
                if (k % 5 == 0) {
                    val l = tm.measure("%02d".format(k), TextStyle(color = Color.White.copy(0.55f * fade), fontSize = 11.sp))
                    drawText(l, topLeft = Offset(p.x - l.size.width / 2f, p.y - l.size.height / 2f))
                } else {
                    drawCircle(Color.White.copy(0.18f * fade), 1.6.dp.toPx(), p)
                }
            }
            // قرص دقیقهٔ فعلی
            val pill = Size(52.dp.toPx(), 30.dp.toPx())
            val pc = Offset(c.x + r, c.y)
            drawRoundRect(
                Color.White, Offset(pc.x - pill.width / 2, pc.y - pill.height / 2), pill,
                androidx.compose.ui.geometry.CornerRadius(pill.height / 2), style = Stroke(1.5.dp.toPx()),
            )
            val ml = tm.measure("%02d".format(minute), TextStyle(color = accent, fontSize = 17.sp, fontWeight = FontWeight.Bold))
            drawText(ml, topLeft = Offset(pc.x - ml.size.width / 2f, pc.y - ml.size.height / 2f))
            // ساعت
            val hl = tm.measure(
                fmt(now, "HH", false).faDigits(ui.fa),
                TextStyle(color = Color.White, fontSize = 46.sp, fontWeight = FontWeight.Light),
            )
            drawText(hl, topLeft = Offset(c.x - hl.size.width / 2f, c.y - hl.size.height / 2f))
        }
        Column(
            Modifier.align(Alignment.CenterEnd).padding(end = 22.dp).tap {
                ctx.safeStart(Intent(AlarmClock.ACTION_SHOW_ALARMS))
            },
            horizontalAlignment = Alignment.End,
        ) {
            Text(fmt(now, "dd MMM y", ui.fa), color = Color.White.copy(0.8f), fontSize = 11.sp)
            Text(fmt(now, "EEEE", ui.fa), color = Dim, fontSize = 11.sp)
        }
        Text(
            "▮ ${battery.level}%".faDigits(ui.fa), color = Dim, fontSize = 11.sp,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 24.dp),
        )
    }
}

/* ---------------- صفحهٔ اصلی دوتکه ---------------- */

@Composable
private fun HomePage(apps: List<AppInfo>, onSettings: () -> Unit, onEditQuote: () -> Unit) {
    val ui = LocalUi.current
    val ctx = LocalContext.current
    val wall = rememberUriBitmap(ui.prefs.get("wallpaper"))
    val listState = rememberLazyListState()
    val curve by animateFloatAsState(if (listState.isScrollInProgress) 1f else 0f, tween(380), label = "curve")
    var query by remember { mutableStateOf<String?>(null) }
    val shown = remember(apps, query) {
        val q = query?.trim().orEmpty()
        if (q.isEmpty()) apps else apps.filter { it.label.contains(q, true) }
    }
    val density = LocalDensity.current
    val shiftPx = with(density) { 70.dp.toPx() }
    val accent = ui.accent

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val panelW = maxWidth * 0.64f
        // نوار والپیپر سمت راست
        Box(Modifier.align(Alignment.CenterEnd).width(maxWidth - panelW + 24.dp).fillMaxHeight().clip(RoundedCornerShape(topStart = 28.dp, bottomStart = 28.dp))) {
            if (wall != null) Image(wall, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            else Image(painterResource(R.drawable.wallpaper), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        // قوس نقطه‌چین هنگام اسکرول
        Canvas(Modifier.fillMaxSize()) {
            if (curve > 0.01f) {
                val top = size.height * 0.48f
                val bottom = size.height * 0.95f
                val baseX = panelW.toPx() + 30.dp.toPx()
                var y = top
                while (y < bottom) {
                    val d = (y - (top + bottom) / 2) / ((bottom - top) / 2)
                    val x = baseX + curve * shiftPx * (1 - d * d)
                    drawCircle(Color.White.copy(0.85f * curve), 2.dp.toPx(), Offset(x, y))
                    y += 14.dp.toPx()
                }
            }
        }

        Column(
            Modifier.width(panelW).fillMaxHeight().statusBarsPadding().navigationBarsPadding().padding(start = 18.dp)
                .pointerInput(Unit) { detectTapGestures(onLongPress = { onSettings() }) },
        ) {
            Spacer(Modifier.height(10.dp))
            Cards(Modifier.fillMaxWidth().height(330.dp), onEditQuote)
            Spacer(Modifier.height(10.dp))

            // نوار اطلاعات / جستجو
            val now = rememberNow()
            val battery = rememberBattery()
            val focus = remember { FocusRequester() }
            Row(Modifier.fillMaxWidth().height(40.dp).padding(end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                if (query == null) {
                    Text(
                        "${fmt(now, "EEE dd MMM", ui.fa)} · ${battery.level}%".faDigits(ui.fa),
                        color = Dim, fontSize = 12.sp, modifier = Modifier.weight(1f),
                    )
                    Icon(Icons.Outlined.Search, "جستجو", tint = Color.White, modifier = Modifier.size(34.dp).clip(CircleShape).tap { query = "" }.padding(7.dp))
                } else {
                    LaunchedEffect(Unit) { focus.requestFocus() }
                    BasicTextField(
                        query!!, { query = it },
                        Modifier.weight(1f).focusRequester(focus).border(1.dp, Color.White.copy(0.3f), CircleShape).padding(horizontal = 14.dp, vertical = 8.dp),
                        textStyle = TextStyle(color = Color.White, fontSize = 14.sp), singleLine = true,
                        cursorBrush = SolidColor(accent),
                    )
                    Icon(Icons.Outlined.Close, "بستن", tint = Color.White, modifier = Modifier.size(34.dp).clip(CircleShape).tap { query = null }.padding(7.dp))
                }
            }

            LazyColumn(state = listState, modifier = Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(vertical = 6.dp)) {
                itemsIndexed(shown, key = { _, a -> a.id }) { index, app ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .graphicsLayer {
                                val info = listState.layoutInfo
                                val item = info.visibleItemsInfo.firstOrNull { it.index == index }
                                if (item != null) {
                                    val half = (info.viewportEndOffset - info.viewportStartOffset) / 2f
                                    val d = ((item.offset + item.size / 2f - half) / half).coerceIn(-1f, 1f)
                                    translationX = curve * shiftPx * (1 - d * d)
                                    alpha = 1f - 0.55f * curve * abs(d)
                                }
                            }
                            .tap(onLong = { ctx.openAppInfo(app) }) { query = null; ctx.launchApp(app) }
                            .padding(vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Image(app.icon, null, Modifier.size(26.dp).clip(CircleShape), colorFilter = mono)
                        Spacer(Modifier.width(14.dp))
                        Text(app.label, color = Color.White, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }
}

private val mono = ColorFilter.colorMatrix(ColorMatrix().apply { setToSaturation(0f) })

/* ---------------- کارت‌های ورق‌خور ---------------- */

@Composable
private fun Cards(modifier: Modifier, onEditQuote: () -> Unit) {
    val ui = LocalUi.current
    val state = rememberPagerState { 3 }
    Box(modifier) {
        HorizontalPager(state, Modifier.fillMaxSize(), pageSpacing = 12.dp) { p ->
            when (p) {
                0 -> QuoteCard(onEditQuote)
                1 -> DayCard()
                else -> ClockCard()
            }
        }
        Row(Modifier.align(Alignment.BottomCenter).padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            repeat(3) { i ->
                Box(
                    Modifier.height(5.dp).width(if (i == state.currentPage) 16.dp else 5.dp)
                        .background(if (i == state.currentPage) ui.accent else Dim, CircleShape)
                )
            }
        }
    }
}

@Composable
private fun QuoteCard(onEdit: () -> Unit) {
    val ui = LocalUi.current
    val now = rememberNow()
    val quote = ui.prefs.get("quote", if (ui.fa) "روز\nبدی\nنیست." else "Not a\nbad\nday.")!!
    Column(Modifier.fillMaxSize().tap(onLong = onEdit) {}.padding(top = 8.dp, end = 8.dp)) {
        Row(
            Modifier.border(1.5.dp, Color.White, CircleShape).padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Outlined.Schedule, null, tint = Color.White, modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(4.dp))
            Text(if (ui.fa) "اکنون" else "Now", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(14.dp))
        Text(
            if (ui.fa) "امروز ${fmt(now, "EEEE d MMMM y", true)}" else "Today's ${fmt(now, "EEEE", false)} of\n${fmt(now, "MMMM dd, y", false)}",
            color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, lineHeight = 16.sp,
        )
        Spacer(Modifier.height(10.dp))
        Text(quote, color = ui.accent, fontSize = 50.sp, fontWeight = FontWeight.Black, lineHeight = 48.sp, letterSpacing = (-1).sp)
        Spacer(Modifier.height(8.dp))
        Canvas(Modifier.size(34.dp, 20.dp)) {
            drawCircle(Color.White, 2.dp.toPx(), Offset(size.width * 0.3f, size.height * 0.2f))
            drawCircle(Color.White, 2.dp.toPx(), Offset(size.width * 0.7f, size.height * 0.2f))
            drawArc(Color.White, 20f, 140f, false, Offset(size.width * 0.15f, -size.height * 0.2f), Size(size.width * 0.7f, size.height), style = Stroke(2.dp.toPx(), cap = StrokeCap.Round))
        }
    }
}

@Composable
private fun DayCard() {
    val ui = LocalUi.current
    val now = rememberNow()
    val day = if (ui.fa) fmt(now, "EEEE", true) else fmt(now, "EEE", false).uppercase()
    Column(Modifier.fillMaxSize().padding(end = 6.dp).clip(RoundedCornerShape(28.dp)).background(Card).padding(18.dp)) {
        Text(
            if (ui.fa) "امروز" else "Today's\n${fmt(now, "EEEE", false)}",
            color = Ink, fontSize = 12.sp, fontWeight = FontWeight.Bold, lineHeight = 14.sp,
        )
        Spacer(Modifier.height(8.dp))
        val big = TextStyle(fontSize = 60.sp, fontWeight = FontWeight.Black, lineHeight = 56.sp, letterSpacing = (-2).sp)
        Text(day, style = big.copy(color = Ink, drawStyle = Stroke(width = 4f)))
        Text(day, style = big.copy(color = ui.accent))
        Text(day, style = big.copy(color = Ink))
        Spacer(Modifier.weight(1f))
        Text(
            "${fmt(now, "MMM y", ui.fa)}  ·  ${fmt(now, "HH:mm", false)}".faDigits(ui.fa),
            color = Ink, fontSize = 12.sp, fontWeight = FontWeight.Medium,
        )
        Spacer(Modifier.height(14.dp))
    }
}

@Composable
private fun ClockCard() {
    val ui = LocalUi.current
    val now = rememberNow()
    val battery = rememberBattery()
    val cal = Calendar.getInstance().apply { timeInMillis = now }
    val dayP = (cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)) / 1440f
    Column(Modifier.fillMaxSize().padding(end = 6.dp).clip(RoundedCornerShape(28.dp)).background(Card).padding(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(4.dp, 22.dp).background(ui.accent, CircleShape))
            Spacer(Modifier.width(8.dp))
            Text(
                "${fmt(now, "EEE", ui.fa)}\n${if (ui.fa) "باتری" else "Battery"} ${battery.level}%".faDigits(ui.fa),
                color = Ink, fontSize = 11.sp, fontWeight = FontWeight.Bold, lineHeight = 13.sp,
            )
        }
        val big = TextStyle(fontSize = 92.sp, fontWeight = FontWeight.Black, lineHeight = 84.sp)
        Text(fmt(now, "HH", false).faDigits(ui.fa), style = big.copy(color = Ink))
        Text(fmt(now, "mm", false).faDigits(ui.fa), style = big.copy(color = Ink, drawStyle = Stroke(width = 5f)))
        Spacer(Modifier.height(10.dp))
        Box(Modifier.fillMaxWidth().height(7.dp).background(Color.Black.copy(0.12f), CircleShape)) {
            Box(Modifier.fillMaxWidth(dayP).fillMaxHeight().background(ui.accent, CircleShape))
        }
        Spacer(Modifier.height(6.dp))
        Text(
            (if (ui.fa) "${(dayP * 100).toInt()}٪ از امروز گذشت" else "${(dayP * 100).toInt()}% of today passed").faDigits(ui.fa),
            color = Ink.copy(0.7f), fontSize = 11.sp,
        )
    }
}

/* ---------------- پنجره‌ها ---------------- */

@Composable
private fun PanelDialog(onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier.fillMaxWidth().background(Color(0xFA1C1C1C), RoundedCornerShape(26.dp)).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            content = content,
        )
    }
}

@Composable
private fun QuoteDialog(prefs: Prefs, onDone: () -> Unit) {
    val ui = LocalUi.current
    var text by remember { mutableStateOf(prefs.get("quote", if (ui.fa) "روز\nبدی\nنیست." else "Not a\nbad\nday.")!!) }
    PanelDialog(onDone) {
        Text("جملهٔ کارت (با Enter خط جدید بسازید)", color = Color.White, fontSize = 16.sp)
        OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth(), maxLines = 5)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            TextButton({ prefs.set("quote", null); onDone() }) { Text("پیش‌فرض", color = Dim) }
            TextButton({ prefs.set("quote", text.trimEnd().ifEmpty { null }); onDone() }) { Text("ذخیره") }
        }
    }
}

@Composable
private fun SettingsDialog(prefs: Prefs, onWallpaper: () -> Unit, onDone: () -> Unit) {
    val ctx = LocalContext.current
    PanelDialog(onDone) {
        Text("تنظیمات لانچر چرخ", color = Color.White, fontSize = 18.sp)
        Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Action("انتخاب به‌عنوان لانچر پیش‌فرض") { ctx.safeStart(Intent(android.provider.Settings.ACTION_HOME_SETTINGS)); onDone() }
            Action("تغییر تصویر نوار کناری") { onWallpaper(); onDone() }
            if (prefs.get("wallpaper") != null) Action("برگشت به تصویر پیش‌فرض") { prefs.set("wallpaper", null) }
            Text("رنگ تأکید", color = Dim, fontSize = 13.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Accents.forEachIndexed { i, c ->
                    val on = prefs.get("accent", "0") == "$i"
                    Box(
                        Modifier.size(36.dp).clip(CircleShape).background(c)
                            .border(if (on) 3.dp else 0.dp, Color.White, CircleShape)
                            .tap { prefs.set("accent", "$i") }
                    )
                }
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("تاریخ شمسی و متن فارسی", color = Color.White, fontSize = 15.sp, modifier = Modifier.weight(1f))
                Switch(prefs.flag("persian", false), { prefs.setFlag("persian", it) })
            }
            Text(
                "راهنما: کارت‌های بالا را به چپ و راست بکشید · روی کارت جمله انگشت نگه دارید تا متنش را عوض کنید · فهرست برنامه‌ها را اسکرول کنید تا قوس را ببینید · از صفحهٔ اصلی به راست بکشید تا ساعت چرخان بیاید",
                color = Dim, fontSize = 12.sp, lineHeight = 18.sp,
            )
        }
    }
}

@Composable
private fun Action(text: String, onClick: () -> Unit) {
    Text(
        text, color = Color.White, fontSize = 15.sp,
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color.White.copy(0.06f))
            .tap(onClick = onClick).padding(14.dp),
    )
}
