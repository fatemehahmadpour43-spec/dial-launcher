package com.dial.launcher

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.BatteryManager
import android.provider.Settings
import android.widget.Toast
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/* ---------------- تنظیمات ---------------- */

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("dial", Context.MODE_PRIVATE)
    private val cache = mutableStateMapOf<String, String>()

    init { sp.all.forEach { (k, v) -> if (v is String) cache[k] = v } }

    fun get(key: String, def: String? = null): String? = cache[key] ?: def
    fun set(key: String, value: String?) {
        if (value == null) { cache.remove(key); sp.edit().remove(key).apply() }
        else { cache[key] = value; sp.edit().putString(key, value).apply() }
    }
    fun flag(key: String, def: Boolean) = get(key)?.toBooleanStrictOrNull() ?: def
    fun setFlag(key: String, on: Boolean) = set(key, on.toString())
}

/* ---------------- برنامه‌ها ---------------- */

data class AppInfo(val label: String, val pkg: String, val activity: String, val icon: ImageBitmap) {
    val id get() = "$pkg/$activity"
}

suspend fun loadApps(context: Context): List<AppInfo> = withContext(Dispatchers.IO) {
    val pm = context.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    pm.queryIntentActivities(intent, 0)
        .filter { it.activityInfo.packageName != context.packageName }
        .mapNotNull { ri ->
            runCatching {
                AppInfo(
                    ri.loadLabel(pm).toString(),
                    ri.activityInfo.packageName,
                    ri.activityInfo.name,
                    ri.loadIcon(pm).toBitmap(120, 120).asImageBitmap(),
                )
            }.getOrNull()
        }
        .sortedBy { it.label.lowercase() }
}

fun Context.safeStart(intent: Intent): Boolean = try {
    startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
} catch (e: Exception) {
    Toast.makeText(this, "برنامه‌ای برای این کار پیدا نشد", Toast.LENGTH_SHORT).show(); false
}

fun Context.launchApp(app: AppInfo) = safeStart(
    Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        .setComponent(ComponentName(app.pkg, app.activity))
        .addFlags(Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
)

fun Context.openAppInfo(app: AppInfo) =
    safeStart(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}")))

/** پنل اعلان‌ها را باز می‌کند (روی بیشتر گوشی‌ها کار می‌کند). */
@SuppressLint("WrongConstant")
fun Context.expandNotifications() {
    runCatching {
        val sbm = getSystemService("statusbar")
        Class.forName("android.app.StatusBarManager").getMethod("expandNotificationsPanel").invoke(sbm)
    }
}

/* ---------------- کمک‌ها ---------------- */

fun String.faDigits(on: Boolean): String =
    if (!on) this else map { if (it in '0'..'9') '۰' + (it - '0') else it }.joinToString("")

@Composable
fun rememberNow(): Long {
    val now by produceState(System.currentTimeMillis()) {
        while (true) {
            value = System.currentTimeMillis()
            delay(1000 - value % 1000)
        }
    }
    return now
}

data class Battery(val level: Int, val charging: Boolean)

@Composable
fun rememberBattery(): Battery {
    val ctx = LocalContext.current
    var state by remember { mutableStateOf(Battery(0, false)) }
    DisposableEffect(Unit) {
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                val lv = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
                val sc = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
                val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                state = Battery(
                    lv * 100 / sc,
                    st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL,
                )
            }
        }
        ContextCompat.registerReceiver(ctx, r, IntentFilter(Intent.ACTION_BATTERY_CHANGED), ContextCompat.RECEIVER_NOT_EXPORTED)
        onDispose { ctx.unregisterReceiver(r) }
    }
    return state
}

@Composable
fun rememberUriBitmap(uri: String?, max: Int = 2400): ImageBitmap? {
    val ctx = LocalContext.current
    val bmp by produceState<ImageBitmap?>(null, uri) {
        value = uri?.let {
            withContext(Dispatchers.IO) {
                runCatching {
                    val src = ImageDecoder.createSource(ctx.contentResolver, Uri.parse(it))
                    ImageDecoder.decodeBitmap(src) { d, info, _ ->
                        val s = max.toFloat() / maxOf(info.size.width, info.size.height)
                        if (s < 1f) d.setTargetSize((info.size.width * s).toInt(), (info.size.height * s).toInt())
                        d.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                    }.asImageBitmap()
                }.getOrNull()
            }
        }
    }
    return bmp
}
